// XMLHandle.cpp: implementation of the CXMLHandle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "XMLAny.h"
#include "XMLHandle.h"
#include "msxml2.h"
#import "msxml4.dll"
#include <iostream.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CXMLHandle::CXMLHandle()
{

}

CXMLHandle::~CXMLHandle()
{

}
UShort CXMLHandle::GetNodList()//���뺺���ַ� �õ���Ӧ�����ַ����У������ǶԵ�ǰ��Ļ��Ϣ����ת��
{
	MSXML2::IXMLDOMDocumentPtr pDoc;//xml�ĵ�
	MSXML2::IXMLDOMNodeListPtr pNodeList;//�ڵ��б�
	MSXML2::IXMLDOMNodePtr pNode;
	MSXML2::IXMLDOMElementPtr pElement = NULL;//�ڵ�
	VARIANT vt;
	int Len=0; 
	WCHAR *Value;
	WCHAR *Name;
	int j = 0;

	try
	{
		if(pDoc.CreateInstance(_uuidof(MSXML2::DOMDocument40)))
		{
		}
		pDoc->load(_T("C://Delay.xml"));

		pDoc->get_documentElement(&pElement);
		if(!pElement->hasChildNodes())//���û�нڵ����˳�
		{	
			Name =(WCHAR *) pElement->GetnodeName();
			return 1;
		}
		Name = (WCHAR *)pElement->GetnodeName();
		pElement->get_childNodes(&pNodeList);
		pNode = pNodeList->nextNode();//һֱ���ұ����ڵ�
		Name = pNode->GetnodeName();
		while(pNode!=NULL)
		{
			j++;	
			//Sleep(100);
			MSXML2::IXMLDOMNodeListPtr pList = NULL;//�ڵ��б�
			MSXML2::IXMLDOMNamedNodeMapPtr pAtt;
			MSXML2::IXMLDOMNodePtr pItem;
			Name =(WCHAR *)pNode->GetnodeName();			
			
			TRACE("\n");
			OutputDebugStringW(Name);
			TRACE(" ");

			//TRACE(Value);
			TRACE("\n");
			pNode->get_attributes(&pAtt);

			if(NULL!=pAtt)
			{
				for(int x=0;x<pAtt->Getlength();x++)
				{
					pItem = pAtt->Getitem(x);//�����ｫ��������ֵȡ����
					Name =(WCHAR *)pItem->GetnodeName();
					TRACE(" ");
					OutputDebugStringW(Name);
				//	vt =pItem->GetnodeTypedValue();	
					vt = pItem->GetnodeValue();	
					Value = (WCHAR *)vt.bstrVal;
					TRACE("= ");
					OutputDebugStringW(Value);
				}

				
			}
		
			int i =  pNode->hasChildNodes();
			if(i!=0)
			{//���ӽڵ�
				pList = pNode->GetchildNodes();
				pNode = pList->nextNode();
				continue;
			}
			else
			{//û���ӽڵ�
				if(NULL==pNode->GetnextSibling())//������ڵ������һ��Ļ�
				{
					pNode = pNode->GetparentNode();//������һ��ڵ�
					pNode = pNode->GetnextSibling();//������һ�����ڵĽڵ�				
					continue;

				}
				else
				{
					pNode=pNode->GetnextSibling();				
					continue;
				}		
				
			}	

		}

	}
	catch(...)
	{
		TRACE("����δ֪����!");
	}	
	return j;
}
