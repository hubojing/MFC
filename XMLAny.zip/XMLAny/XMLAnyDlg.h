// XMLAnyDlg.h : header file
//

#if !defined(AFX_XMLANYDLG_H__946991D1_D1FF_4D5B_8750_A8157B6C160E__INCLUDED_)
#define AFX_XMLANYDLG_H__946991D1_D1FF_4D5B_8750_A8157B6C160E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CXMLAnyDlg dialog

class CXMLAnyDlg : public CDialog
{
// Construction
public:
	CXMLAnyDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CXMLAnyDlg)
	enum { IDD = IDD_XMLANY_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXMLAnyDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CXMLAnyDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XMLANYDLG_H__946991D1_D1FF_4D5B_8750_A8157B6C160E__INCLUDED_)
